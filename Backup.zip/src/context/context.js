"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContextProvider = void 0;
const react_1 = require("react");
const Context = (0, react_1.createContext)({});
exports.default = Context;
// eslint-disable-next-line react/prop-types
function ContextProvider({ children }) {
    let [setting, changeSetting] = (0, react_1.useState)(1);
    return (React.createElement(Context.Provider, { value: {
            settingsMenu: {
                value: setting, setValue: changeSetting
            }
        } }, children));
}
exports.ContextProvider = ContextProvider;
