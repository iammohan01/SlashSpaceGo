export default function Logo(){
    return (
        <div className={"logo"}>
            logo
        </div>
    )
}