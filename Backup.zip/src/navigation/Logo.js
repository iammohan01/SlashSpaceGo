"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function Logo() {
    return (React.createElement("div", { className: "logo" }, "logo"));
}
exports.default = Logo;
