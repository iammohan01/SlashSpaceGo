"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("./NavBar.css");
const Logo_jsx_1 = __importDefault(require("./Logo.jsx"));
const RenderSettingMenu_jsx_1 = __importDefault(require("./RenderSettingMenu.jsx"));
function SideNavBar() {
    return (React.createElement("div", { className: "side-nav-bar" },
        React.createElement(Logo_jsx_1.default, null),
        React.createElement(RenderSettingMenu_jsx_1.default, null)));
}
exports.default = SideNavBar;
