"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const antd_1 = require("antd");
const react_1 = require("react");
const context_jsx_1 = __importDefault(require("../context/context.jsx"));
function RenderSettingMenu() {
    const { settingsMenu } = (0, react_1.useContext)(context_jsx_1.default);
    function getItem(label, key, icon, children, type) {
        return { key, icon, children, label, type };
    }
    const items = [
        getItem('Shortcuts', 1),
        getItem('Groups', 2),
        getItem('Settings', 3)
    ];
    return (React.createElement("div", { style: {} },
        React.createElement(antd_1.Menu, { defaultSelectedKeys: ['1'], defaultOpenKeys: ['sub1'], mode: "inline", onClick: (e) => {
                settingsMenu.setValue(Number(e.key));
            }, style: {
                width: 256,
                display: "flex",
                flexDirection: "column",
            }, items: items })));
}
exports.default = RenderSettingMenu;
