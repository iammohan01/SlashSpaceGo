"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const NavBar_jsx_1 = __importDefault(require("./navigation/NavBar.jsx"));
const SettingsPanel_jsx_1 = __importDefault(require("./setting_panel/SettingsPanel.jsx"));
require("@fontsource/poppins/");
function App() {
    return (React.createElement(React.Fragment, null,
        React.createElement(NavBar_jsx_1.default, null),
        React.createElement(SettingsPanel_jsx_1.default, null)));
}
exports.default = App;
