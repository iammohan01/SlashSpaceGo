"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const icons_1 = require("@ant-design/icons");
const antd_1 = require("antd");
function EditShortcut({ shortcut }) {
    function onClick(e) {
        console.log(shortcut, e);
    }
    return (React.createElement(antd_1.Tooltip, { color: "rgba(0,0,0,0.7)", title: "Edit shortcut" },
        React.createElement("span", { onClick: onClick, className: "edit", key: "edit" },
            React.createElement(icons_1.EditOutlined, null))));
}
exports.default = EditShortcut;
