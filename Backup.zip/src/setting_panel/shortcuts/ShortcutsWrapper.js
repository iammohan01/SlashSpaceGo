"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Groups = void 0;
const LoadShortcuts_jsx_1 = __importDefault(require("./LoadShortcuts.jsx"));
function ShortcutsWrapper() {
    return (React.createElement("div", { className: "panel-inner-wrapper" },
        React.createElement("div", { className: "panel-header" },
            React.createElement("h2", null, "Saved Shortcuts")),
        React.createElement(LoadShortcuts_jsx_1.default, null)));
}
exports.default = ShortcutsWrapper;
function Groups() {
    return (React.createElement("div", { className: "panel-inner-wrapper" },
        React.createElement("div", null, "Hello2")));
}
exports.Groups = Groups;
