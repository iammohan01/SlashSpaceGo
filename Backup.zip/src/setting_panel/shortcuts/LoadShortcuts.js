"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const antd_1 = require("antd");
const EditShortcut_jsx_1 = __importDefault(require("./EditShortcut.jsx"));
function LoadShortcuts() {
    const [storedShortcuts, setStoredShortcuts] = (0, react_1.useState)([]);
    (0, react_1.useEffect)(() => {
        chrome.storage.sync.get("shortcuts").then(data => {
            setStoredShortcuts(renderShortcut(data));
        });
    }, []);
    return storedShortcuts;
}
exports.default = LoadShortcuts;
function renderShortcut({ shortcuts }) {
    function LoadEmpty() {
        return (React.createElement(antd_1.Empty, { image: antd_1.Empty.PRESENTED_IMAGE_SIMPLE, imageStyle: { height: 60 }, description: React.createElement("span", null, "No shortcuts available") },
            React.createElement(antd_1.Button, { type: "primary" }, "Create New")));
    }
    function renderItem(shortcut, index) {
        console.log(shortcut);
        return React.createElement(antd_1.List.Item, { key: shortcut.id, className: "shortcut", actions: [React.createElement(EditShortcut_jsx_1.default, { key: shortcut, shortcut: shortcut })] },
            React.createElement(antd_1.List.Item.Meta, { style: { cursor: "pointer" }, title: React.createElement("p", null, index + 1 + " . " + shortcut.key), description: React.createElement("a", { href: shortcut.url }, shortcut.url) }));
    }
    if (shortcuts) {
        shortcuts = shortcuts = Object.entries(shortcuts || {})
            .sort((a, b) => b[1].invoke - a[1].invoke)
            .reduce((acc, [key, value]) => {
            acc[key] = value;
            return acc;
        }, {});
        return (React.createElement(antd_1.List, { dataSource: Object.values(shortcuts), renderItem: renderItem }));
    }
    else {
        return (React.createElement("div", { className: "empty" },
            React.createElement(LoadEmpty, null)));
    }
}
