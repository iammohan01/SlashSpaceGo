"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(require("react"));
const lightnig_svg_1 = __importDefault(require("../../public/resources/icons/lightnig.svg"));
const share_svg_1 = __importDefault(require("../../public/resources/icons/share.svg"));
function Header() {
    return (react_1.default.createElement("div", { className: "header" },
        react_1.default.createElement("div", { className: "icon" },
            react_1.default.createElement("img", { src: "", alt: "", srcSet: lightnig_svg_1.default })),
        react_1.default.createElement("div", { className: "title" }, "SLASH SPACE GO"),
        react_1.default.createElement("div", { className: "share" },
            react_1.default.createElement("img", { src: "", alt: "", srcSet: share_svg_1.default }))));
}
exports.default = Header;
