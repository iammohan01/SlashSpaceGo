"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const antd_1 = require("antd");
const react_1 = __importStar(require("react"));
const utils_js_1 = require("../../utils/utils.js");
const PopupContext_js_1 = __importDefault(require("../context/PopupContext.js"));
const Help_svg_1 = __importDefault(require("../../../public/resources/icons/Help.svg"));
const ShortcutsUtils_js_1 = require("../../Models/SlashSpaceGo/Shortcuts/ShortcutsUtils.js");
const shortcuts_1 = require("@_types/shortcuts");
function CreateShortCut() {
    const { shortCuts, shortcutKeyInput } = (0, react_1.useContext)(PopupContext_js_1.default);
    const [_, setShortcutsInContext] = shortCuts;
    const [key, setKey] = shortcutKeyInput;
    const [target, __] = (0, react_1.useState)(shortcuts_1.UrlTarget.SAME_TAB);
    const [showToast, ___] = (0, react_1.useState)(react_1.default.createElement(react_1.default.Fragment, null));
    const [messageApi, contextHolder] = antd_1.message.useMessage();
    const inputRef = (0, react_1.useRef)(null);
    (0, react_1.useEffect)(() => {
        inputRef?.current?.focus();
    }, []);
    const handleKeyDown = (event) => {
        if (event.key === 'Enter') {
            initSaveShortcut();
        }
    };
    function initSaveShortcut() {
        const trimmedKey = key.trim();
        if (trimmedKey) {
            messageApi.open({
                type: 'loading',
                content: 'Saving shortcut',
                duration: 0,
            }).then();
            (0, utils_js_1.generateCurrentTabData)(trimmedKey, target).then(data => {
                console.log(data);
                (0, ShortcutsUtils_js_1.saveShortcut)(data).then(s => {
                    console.log("saved");
                    setShortcutsInContext(prev => [...prev, s]);
                    antd_1.message.success("saved", 2).then(() => {
                        console.log("saved shortcuts");
                    });
                })
                    .catch(err => {
                    console.error(err);
                    antd_1.message.error("Shortcut Already Used", 3).then(() => {
                        console.log("key already used");
                    });
                }).finally(() => {
                    messageApi.destroy();
                });
            })
                .catch(err => {
                console.error(err);
                antd_1.message.error("Something went wrong", 3)
                    .then(() => {
                    console.log("Something went wrong");
                });
            });
        }
        else {
            messageApi.open({
                type: 'warning',
                content: 'Enter shortcut name'
            }).then(() => {
            });
        }
    }
    return react_1.default.createElement("div", { tabIndex: -1, onKeyDown: handleKeyDown, className: "create-shortcut-wrapper" },
        contextHolder,
        !!showToast && showToast,
        react_1.default.createElement("div", { className: "input-fields" },
            react_1.default.createElement("span", null, "/ SPACE"),
            react_1.default.createElement("input", { ref: inputRef, value: key, onChange: (e) => {
                    setKey(e.target.value.trim());
                }, id: "create-input", type: "text", placeholder: "Enter a shortcut name" }),
            react_1.default.createElement("label", { htmlFor: "target" },
                react_1.default.createElement("select", { name: "option for page", id: "target" },
                    react_1.default.createElement("option", { value: "1" }, "same tab"),
                    react_1.default.createElement("option", { value: "2" }, "new tab"),
                    react_1.default.createElement("option", { value: "3" }, "new window"))),
            react_1.default.createElement(antd_1.Tooltip, { title: `For quick access to a saved website: Press "/", followed by a space and the shortcut name. Then, hit Enter` },
                react_1.default.createElement("img", { className: "help-icon shortcut", src: "", alt: "", srcSet: Help_svg_1.default }))),
        react_1.default.createElement("div", { className: "button-fields", onClick: initSaveShortcut },
            react_1.default.createElement("button", { className: "button", id: "saveButton" }, "Save")));
}
exports.default = CreateShortCut;
