"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const PopupContext_js_1 = __importDefault(require("../context/PopupContext.js"));
const utils_js_1 = require("../../utils/utils.js");
const meta_svg_1 = __importDefault(require("../../../public/resources/icons/meta.svg"));
const ctrl_svg_1 = __importDefault(require("../../../public/resources/icons/ctrl.svg"));
const empty_svg_1 = __importDefault(require("../../../public/resources/icons/empty.svg"));
const antd_1 = require("antd");
const ShortcutsUtils_js_1 = require("../../Models/SlashSpaceGo/Shortcuts/ShortcutsUtils.js");
const shortcuts_1 = require("@_types/shortcuts");
const react_2 = __importDefault(require("react"));
function RenderShortcut({ shortCut, index, isMacOs }) {
    const { shortCuts, layout } = (0, react_1.useContext)(PopupContext_js_1.default);
    const [_, setShortCuts] = shortCuts;
    const [layoutCtx, __] = layout;
    function onclick() {
        (0, utils_js_1.openTarget)(shortCut);
    }
    const children = react_2.default.createElement("div", { onClick: onclick, draggable: "true", className: layoutCtx.toString() },
        layoutCtx === shortcuts_1.View.GRID && index < 10 && react_2.default.createElement("div", { className: "keyShortcut" },
            react_2.default.createElement("img", { src: isMacOs ? meta_svg_1.default : ctrl_svg_1.default, alt: "shortcutIcons" }),
            index),
        layoutCtx === shortcuts_1.View.GRID &&
            react_2.default.createElement("img", { style: { width: 14, aspectRatio: "1/1" }, src: shortCut.favIconUrl || empty_svg_1.default, alt: "fav icon" }),
        layoutCtx === shortcuts_1.View.GRID && (shortCut.key.slice(0, 6)),
        layoutCtx === shortcuts_1.View.GRID && shortCut.key.length > 6 && "...",
        layoutCtx === shortcuts_1.View.LIST && react_2.default.createElement("h6", null,
            react_2.default.createElement("img", { style: { width: 14, aspectRatio: "1/1" }, src: shortCut.favIconUrl || empty_svg_1.default, alt: "" }),
            " ",
            index,
            " . ",
            shortCut.key),
        layoutCtx === shortcuts_1.View.LIST && react_2.default.createElement("p", { className: "url" },
            shortCut.url,
            " "));
    return react_2.default.createElement(antd_1.Popover, { content: react_2.default.createElement("div", { style: {
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "0.7rem",
                maxWidth: "90vw"
            } },
            react_2.default.createElement("span", { style: { fontSize: "0.7rem", wordWrap: "break-word", whiteSpace: "pre-wrap" } }, shortCut.url),
            react_2.default.createElement("div", { style: { display: "flex", fontSize: "0.7rem", alignItems: "center", justifyContent: "center", gap: "1rem" } },
                react_2.default.createElement("a", null, "Edit"),
                react_2.default.createElement("a", { onClick: () => {
                        (0, ShortcutsUtils_js_1.deleteShortcut)(shortCut.key).then(r => {
                            console.log(r, "deleted");
                            setShortCuts(prev => prev.filter(obj => obj.key !== shortCut.key));
                        });
                    } }, "Delete"),
                react_2.default.createElement("a", { onClick: () => {
                        (0, utils_js_1.openTarget)(shortCut, 1);
                    } }, "open"))), mouseEnterDelay: 0.5, mouseLeaveDelay: 0.3 }, children);
}
exports.default = RenderShortcut;
