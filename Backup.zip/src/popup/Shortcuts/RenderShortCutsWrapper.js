"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const PopupContext_js_1 = __importStar(require("../context/PopupContext.js"));
const react_1 = __importStar(require("react"));
const antd_1 = require("antd");
const utils_js_1 = require("../../utils/utils.js");
const view_list_svg_1 = __importDefault(require("../../../public/resources/icons/view_list.svg"));
const view_grid_svg_1 = __importDefault(require("../../../public/resources/icons/view_grid.svg"));
const RenderShortcut_js_1 = __importDefault(require("./RenderShortcut.js"));
const shortcuts_1 = require("@_types/shortcuts");
function RenderShortCutsWrapper() {
    const { shortCuts, layout } = (0, react_1.useContext)(PopupContext_js_1.default);
    const [shortCutsCtx, _] = shortCuts;
    const [layoutCtx, setLayoutCtx] = layout;
    const [shortCutItems, setShortCutItems] = (0, react_1.useState)([]);
    (0, react_1.useEffect)(() => {
        let sortedShortcuts;
        function attachKeyboardShortcut(event) {
            const key = event.which;
            if (48 <= key && key <= 57) {
                if (PopupContext_js_1.isMacOs && event.metaKey) {
                    event.preventDefault();
                    console.log("mac os");
                    (0, utils_js_1.openTarget)(sortedShortcuts[Number(event.key)]);
                }
                else if (!PopupContext_js_1.isMacOs && event.ctrlKey) {
                    event.preventDefault();
                    console.log("windows or linux");
                    (0, utils_js_1.openTarget)(sortedShortcuts[Number(event.key)]);
                }
            }
        }
        if (shortCutsCtx && shortCutsCtx.length > 0) {
            sortedShortcuts = shortCutsCtx;
            sortedShortcuts.sort((a, b) => b.invoke - a.invoke);
            const renderedShortcuts = [];
            document.addEventListener('keydown', attachKeyboardShortcut);
            for (let index = 0; index < sortedShortcuts.length; index++) {
                const val = sortedShortcuts[index];
                renderedShortcuts.push(react_1.default.createElement(RenderShortcut_js_1.default, { isMacOs: PopupContext_js_1.isMacOs, key: index, shortCut: val, index: index }));
            }
            setShortCutItems(renderedShortcuts);
        }
        return () => {
            document.removeEventListener('keydown', attachKeyboardShortcut);
        };
    }, [shortCutsCtx]);
    return (react_1.default.createElement("div", { className: "freq-suggest-wrapper" },
        react_1.default.createElement("input", { style: { display: "none" }, placeholder: "Search shortcut" }),
        react_1.default.createElement("h4", { className: "title" },
            "Frequently Used Shortcuts",
            react_1.default.createElement(antd_1.Tooltip, { title: "Change layout", mouseEnterDelay: 1, mouseLeaveDelay: 0.25 },
                react_1.default.createElement("span", { style: { cursor: "pointer" }, onClick: () => {
                        setLayoutCtx(prev => {
                            if (prev === shortcuts_1.View.LIST) {
                                return shortcuts_1.View.GRID;
                            }
                            return shortcuts_1.View.LIST;
                        });
                    }, className: "view" },
                    react_1.default.createElement("img", { src: layoutCtx === shortcuts_1.View.GRID ? view_list_svg_1.default : view_grid_svg_1.default, alt: "View List" })))),
        react_1.default.createElement("div", { className: "frq-shortcuts" }, shortCutItems)));
}
exports.default = RenderShortCutsWrapper;
