"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const antd_1 = require("antd");
const Help_svg_1 = __importDefault(require("../../../public/resources/icons/Help.svg"));
const react_1 = require("react");
const PopupContext_tsx_1 = __importDefault(require("../context/PopupContext.tsx"));
const TextExpanderUtils_js_1 = require("../../Models/SlashSpaceGo/TextExpander/TextExpanderUtils.js");
const { TextArea } = antd_1.Input;
function CreateExpander() {
    const { expanderKey, expanderInput } = (0, react_1.useContext)(PopupContext_tsx_1.default);
    const [messageApi, contextHolder] = antd_1.message.useMessage();
    function initiateAddingTextExpander() {
        let key = expanderKey[0];
        let value = expanderInput[0];
        let isKeyAvailable = !!key.trim();
        let isValueAvailable = !!value.trim();
        if (isKeyAvailable && isValueAvailable) {
            messageApi
                .open({
                type: 'loading',
                content: 'Saving Expander',
                duration: 0,
            });
            (0, TextExpanderUtils_js_1.saveExpander)(key, value)
                .then(s => {
                console.log("saved");
                antd_1.message.success("saved", 2);
            })
                .catch(err => {
                console.error(err);
                antd_1.message.error("Key Already Used", 3);
            })
                .finally(() => {
                messageApi.destroy();
            });
        }
        else {
            console.log(isKeyAvailable, isValueAvailable);
            messageApi.open({
                type: 'warning',
                content: `Enter Expander ${!isKeyAvailable ? "key" : "value"}`
            });
        }
    }
    function handleKeyDown(event) {
        if (event.which === 13) {
            initiateAddingTextExpander();
        }
    }
    return (React.createElement(React.Fragment, null,
        contextHolder,
        React.createElement(KeyInput, { handleKeyDown: handleKeyDown, state: expanderKey }),
        React.createElement(ValueInput, { state: expanderInput }),
        React.createElement("div", { className: "button-fields" },
            React.createElement("button", { onClick: initiateAddingTextExpander, className: "button", id: "saveButton" }, "Save"))));
}
exports.default = CreateExpander;
function KeyInput({ state, handleKeyDown }) {
    const inputRef = (0, react_1.useRef)(null);
    const [key, setKey] = state;
    (0, react_1.useEffect)(() => {
        inputRef?.current?.focus();
    }, []);
    return React.createElement("div", { onKeyDown: handleKeyDown, className: "input-fields" },
        React.createElement("span", null, "/ SPACE"),
        React.createElement("input", { ref: inputRef, value: key, onChange: (e) => {
                setKey(e?.target?.value?.trim());
            }, id: "create-input", type: "text", placeholder: "Enter a shortcut name" }),
        React.createElement("label", { htmlFor: "target" },
            React.createElement("select", { name: "option for page", id: "target" },
                React.createElement("option", { value: "1" }, "same tab"),
                React.createElement("option", { value: "2" }, "new tab"),
                React.createElement("option", { value: "3" }, "new window"))),
        React.createElement(antd_1.Tooltip, { title: `For quick access to a saved large text with in shortcuts: Press "/", followed by a space and the shortcut name. Then, hit Enter` },
            React.createElement("img", { className: "help-icon shortcut", src: "", alt: "", srcSet: Help_svg_1.default })));
}
function ValueInput({ state }) {
    const [value, setValue] = state;
    function updateInput(e) {
        setValue(e.target.value);
    }
    return (React.createElement(React.Fragment, null,
        React.createElement(TextArea, { value: value, style: { margin: "5%", width: "90%", resize: "none", height: 180 }, showCount: true, onChange: updateInput, placeholder: "Paste or Enter Text here" })));
}
