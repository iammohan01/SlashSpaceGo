import CreateExpander from "./CreateExpander.jsx";

export default function TextExpander(){
    return (
        <CreateExpander/>
    )
}