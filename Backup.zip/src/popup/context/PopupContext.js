"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContextProvider = exports.isMacOs = void 0;
const react_1 = __importStar(require("react"));
const ShortcutsUtils_1 = __importDefault(require("../../Models/SlashSpaceGo/Shortcuts/ShortcutsUtils"));
const shortcuts_1 = require("@_types/shortcuts");
exports.isMacOs = navigator.userAgentData.platform === "macOS";
const PopupContext = (0, react_1.createContext)({});
function ContextProvider({ children }) {
    const [shortcuts, setShortcuts] = (0, react_1.useState)([]);
    const [layout, setLayout] = (0, react_1.useState)(shortcuts_1.View.GRID);
    const [shortCutKey, setShortcutKey] = (0, react_1.useState)("");
    const [expanderKey, setExpanderKey] = (0, react_1.useState)("");
    const [expanderInput, setExpanderInput] = (0, react_1.useState)("");
    (0, react_1.useEffect)(() => {
        (0, ShortcutsUtils_1.default)().then(shortcuts => {
            setShortcuts(shortcuts);
        });
    }, []);
    return (react_1.default.createElement(PopupContext.Provider, { value: {
            shortCuts: [shortcuts, setShortcuts],
            layout: [layout, setLayout],
            shortcutKeyInput: [shortCutKey, setShortcutKey],
            expanderKey: [expanderKey, setExpanderKey],
            expanderInput: [expanderInput, setExpanderInput]
        } }, children));
}
exports.ContextProvider = ContextProvider;
exports.default = PopupContext;
