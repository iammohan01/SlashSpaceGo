import React, {createContext, useEffect, useState} from "react";
import fetchAllShortcuts from "../../Models/SlashSpaceGo/Shortcuts/ShortcutsUtils";
import {View} from "@_types/shortcuts";


export const isMacOs = navigator.userAgentData.platform === "macOS";


interface PopupContextType {
    shortCuts: [any[], React.Dispatch<React.SetStateAction<any[]>>];
    layout: [View, React.Dispatch<React.SetStateAction<View>>];
    shortcutKeyInput: [string, React.Dispatch<React.SetStateAction<string>>];
    expanderKey: [string, React.Dispatch<React.SetStateAction<string>>];
    expanderInput: [string, React.Dispatch<React.SetStateAction<string>>];
}

const PopupContext = createContext<PopupContextType>({});
type Props = { children: React.ReactElement }

export function ContextProvider({children}: Props) {
    const [shortcuts, setShortcuts] = useState<any[]>([])
    const [layout, setLayout] = useState<View>(View.GRID)
    const [shortCutKey, setShortcutKey] = useState<string>("")
    const [expanderKey, setExpanderKey] = useState<string>("")
    const [expanderInput, setExpanderInput] = useState<string>("")

    useEffect(() => {
       fetchAllShortcuts().then(shortcuts=>{
           setShortcuts(shortcuts)
       })
    }, []);

    return (<PopupContext.Provider
        value=
            {{
                shortCuts: [shortcuts, setShortcuts],
                layout: [layout, setLayout],
                shortcutKeyInput: [shortCutKey, setShortcutKey],
                expanderKey:[expanderKey,setExpanderKey],
                expanderInput:[expanderInput,setExpanderInput]
            }}
    >
            {children}
    </PopupContext.Provider>)
}

export default PopupContext;
