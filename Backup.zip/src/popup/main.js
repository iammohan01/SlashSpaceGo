"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = __importDefault(require("react-dom/client"));
const PopupContext_tsx_1 = require("./context/PopupContext.tsx");
const Popup_tsx_1 = __importDefault(require("./Popup.tsx"));
require("../styles/popup.css");
require("@fontsource/poppins/");
client_1.default.createRoot(document.getElementById('root')).render(React.createElement(PopupContext_tsx_1.ContextProvider, null,
    React.createElement(Popup_tsx_1.default, null)));
