import ReactDOM from 'react-dom/client'
import {ContextProvider} from "./context/PopupContext.tsx";
import Popup from "./Popup.tsx";
import "../styles/popup.css"
import '@fontsource/poppins/';

ReactDOM.createRoot(document.getElementById('root')).render(
    <ContextProvider>
        <Popup/>
    </ContextProvider>
)
