"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateCurrentTabData = exports.openTarget = exports.getCurrentActiveTab = exports.createNewWindow = exports.goToUrl = exports.getActiveTab = exports.generateRandomString = void 0;
const crypto_random_string_1 = __importDefault(require("crypto-random-string"));
const ShortcutsUtils_1 = require("../Models/SlashSpaceGo/Shortcuts/ShortcutsUtils");
const shortcuts_1 = require("@_types/shortcuts");
function generateRandomString(length) {
    return (0, crypto_random_string_1.default)({ length: length, type: 'alphanumeric' });
}
exports.generateRandomString = generateRandomString;
function getActiveTab() {
    return chrome.tabs.query({ active: true, currentWindow: true });
}
exports.getActiveTab = getActiveTab;
function goToUrl(tabId, url) {
    return chrome.tabs.update(tabId, { url: url });
}
exports.goToUrl = goToUrl;
function createNewWindow() {
    return chrome.windows.create();
}
exports.createNewWindow = createNewWindow;
function getCurrentActiveTab() {
    return chrome.tabs.query({ active: true, currentWindow: true });
}
exports.getCurrentActiveTab = getCurrentActiveTab;
function openTarget(shortcut, target = shortcuts_1.UrlTarget.SAME_TAB) {
    shortcut.invoke++;
    if (!target) {
        target = shortcut.target;
    }
    (0, ShortcutsUtils_1.updateInvoke)(shortcut);
    if (target === shortcuts_1.UrlTarget.SAME_TAB) {
        getCurrentActiveTab().then(tab => {
            if (tab !== undefined && tab[0] && tab[0].id !== undefined) {
                goToUrl(tab[0].id, shortcut.url).then(() => {
                    console.log("target opened");
                });
            }
        });
    }
    else if (target === shortcuts_1.UrlTarget.NEW_TAB) {
        chrome.tabs.create({ url: shortcut.url }).then(tab => {
            console.log(tab);
        });
    }
    else if (target === shortcuts_1.UrlTarget.NEW_WINDOW) {
        createNewWindow().then(window => {
            if (window.tabs && window.tabs[0] && window.tabs[0] !== undefined) {
                const tab = window.tabs[0];
                console.log("Going to open new window");
                if (tab !== undefined && tab.id !== undefined) {
                    goToUrl(tab.id, shortcut.url).then(() => {
                        console.log("new window opened");
                    });
                }
            }
        });
    }
}
exports.openTarget = openTarget;
async function generateCurrentTabData(key, target) {
    return getActiveTab().then(currentTab => {
        return {
            createdTime: Date.now(),
            favIconUrl: currentTab[0].favIconUrl,
            id: generateRandomString(15),
            invoke: 0,
            key: key,
            modifiedTime: Date.now(),
            target: target || shortcuts_1.UrlTarget.SAME_TAB,
            title: currentTab[0].title,
            url: currentTab[0].url
        };
    });
}
exports.generateCurrentTabData = generateCurrentTabData;
