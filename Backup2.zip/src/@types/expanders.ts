type Expanders = {
    key: string
    value: string
    createdTime: number
    id: string
    invoke: number
    modifiedTime: number
}
export type {Expanders}