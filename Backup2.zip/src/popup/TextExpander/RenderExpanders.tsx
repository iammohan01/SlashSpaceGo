import {Expanders} from "../../@types/expanders";
import {MouseEvent, useContext} from "react";
import PopupContext from "../context/PopupContext";
import {View} from "../../@types/shortcuts";

type MakeExpanderProperties = {
    expanderProperty: Expanders[]
}
type ItemProperty = {
    expanderProperty: Expanders
    index: number
}
export type {MakeExpanderProperties}

export function RenderExpanders({expanderProperty}: MakeExpanderProperties) {
    return (
        <div className={"frq-expanders"}>{
            expanderProperty
                .map((value, index, array) => {
                    return <RenderExpanderItems key={value.id} expanderProperty={value} index={index}/>
                })}
        </div>
    )
}

function RenderExpanderItems({expanderProperty, index}: ItemProperty) {

    const {layout} = useContext(PopupContext)
    const [layoutSetting, changeLayoutSetting] = layout

    function viewExpanderInfor(e: MouseEvent) {
        console.log("Expander info , ", e, expanderProperty)
    }

    return <div onClick={viewExpanderInfor} draggable="true" className={layoutSetting === View.GRID ? "grid" : "list"}>
        {index} . {expanderProperty.key}
    </div>
}