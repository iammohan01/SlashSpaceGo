import CreateExpander from "./CreateExpander";
import {ViewExpanders} from "./ViewExpanders";

export default function TextExpander() {
    return (
        <div>
            <CreateExpander/>
            {/*<ViewExpanders/>*/}
        </div>
    )
}